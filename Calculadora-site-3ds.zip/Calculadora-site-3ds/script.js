(() => {
  const display = document.getElementById('display');
  const keys = document.querySelector('.keys');

  let expr = '';

  function updateDisplay() {
    display.textContent = expr === '' ? '0' : expr;
  }

  function safeEvaluate(s) {
    // allow only digits, operators, dot, parentheses and percent
    if (!/^[0-9+\-*/().%\s]+$/.test(s)) throw new Error('Caracter inválido');
    // replace percent: 50% -> (50/100)
    s = s.replace(/(\d+(?:\.\d+)?)%/g, '($1/100)');
    // evaluate using Function to avoid direct eval in global scope
    // still basic; do not use for untrusted remote input
    // eslint-disable-next-line no-new-func
    return Function('return ' + s)();
  }

  keys.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const action = btn.dataset.action;
    const value = btn.dataset.value;

    if (action === 'clear') { expr = ''; updateDisplay(); return; }
    if (action === 'back') { expr = expr.slice(0, -1); updateDisplay(); return; }
    if (action === 'percent') { expr += '%'; updateDisplay(); return; }
    if (action === 'equals') {
      try {
        const res = safeEvaluate(expr || '0');
        expr = String(res);
      } catch (err) {
        expr = 'Erro';
      }
      updateDisplay();
      return;
    }

    // normal button (number/operator)
    if (value) {
      expr += value;
      updateDisplay();
    }
  });

  // keyboard support
  window.addEventListener('keydown', (e) => {
    const allowed = '0123456789+-*/().%';
    if (e.key === 'Enter') { e.preventDefault(); document.querySelector('[data-action="equals"]').click(); return; }
    if (e.key === 'Backspace') { document.querySelector('[data-action="back"]').click(); return; }
    if (e.key === 'Escape') { document.querySelector('[data-action="clear"]').click(); return; }
    if (allowed.includes(e.key)) { expr += e.key; updateDisplay(); }
  });

  updateDisplay();
})();
