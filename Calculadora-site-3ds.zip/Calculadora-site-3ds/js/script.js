/*
  js/script.js
  Lógica da Calculadora Pro
  - Mobile-first, acessível (teclado e ARIA)
  - Preparada para integração com API (função sendCalculationToApi)
*/
(function () {
  'use strict';

  const display = document.getElementById('display');
  const keys = document.querySelector('.calc__keys');
  const historyList = document.getElementById('history');

  let expression = '';
  const calcHistory = [];

  function updateDisplay(text) {
    display.textContent = text === undefined ? (expression || '0') : text;
  }

  function pushHistory(entry) {
    calcHistory.unshift(entry);
    // keep 50 items max
    if (calcHistory.length > 50) calcHistory.pop();
    renderHistory();
  }

  function renderHistory() {
    historyList.innerHTML = '';
    calcHistory.forEach(item => {
      const li = document.createElement('li');
      li.textContent = item;
      historyList.appendChild(li);
    });
  }

  // Basic sanitizer: allow digits, operators, parentheses, dot, percent and spaces
  function sanitize(input) {
    if (typeof input !== 'string') return '';
    if (!/^[0-9+\-*/().%\s]+$/.test(input)) throw new Error('Entrada contém caracteres inválidos');
    return input;
  }

  function evaluateExpression(expr) {
    // convert percent occurrences (e.g., 50% -> (50/100))
    const transformed = expr.replace(/(\d+(?:\.\d+)?)%/g, '($1/100)');
    // eslint-disable-next-line no-new-func
    const result = Function('return ' + transformed)();
    return result;
  }

  function handleEquals() {
    try {
      const safe = sanitize(expression || '0');
      const result = evaluateExpression(safe);
      const entry = `${expression} = ${result}`;
      updateDisplay(String(result));
      pushHistory(entry);
      // API integration placeholder (send history or result)
      sendCalculationToApi({ expression, result }).catch(() => {});
      expression = String(result);
    } catch (err) {
      updateDisplay('Erro');
      setTimeout(() => updateDisplay('0'), 1500);
      expression = '';
    }
  }

  function handleKeyInput(value) {
    expression += value;
    updateDisplay();
  }

  keys.addEventListener('click', (ev) => {
    const btn = ev.target.closest('button');
    if (!btn) return;

    const action = btn.dataset.action;
    const value = btn.dataset.value;

    if (action === 'clear') { expression = ''; updateDisplay(); return; }
    if (action === 'back') { expression = expression.slice(0, -1); updateDisplay(); return; }
    if (action === 'percent') { expression += '%'; updateDisplay(); return; }
    if (action === 'equals') { handleEquals(); return; }
    if (value) { handleKeyInput(value); }
  });

  // Keyboard support
  window.addEventListener('keydown', (e) => {
    const allowed = '0123456789+-*/().%';
    if (e.key === 'Enter') { e.preventDefault(); handleEquals(); return; }
    if (e.key === 'Backspace') { e.preventDefault(); expression = expression.slice(0, -1); updateDisplay(); return; }
    if (e.key === 'Escape') { e.preventDefault(); expression = ''; updateDisplay(); return; }
    if (allowed.includes(e.key)) { e.preventDefault(); expression += e.key; updateDisplay(); }
  });

  // Placeholder for API integration (returns promise)
  async function sendCalculationToApi(payload) {
    // Example: POST to /api/calculations — adjust endpoint later
    try {
      const res = await fetch('/api/calculations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('API error');
      return res.json();
    } catch (err) {
      // Do not block UI on API failure; logging for dev
      console.warn('sendCalculationToApi failed', err);
      throw err;
    }
  }

  // Initial render
  updateDisplay();
  renderHistory();

  // Expose for debugging in future (optional)
  window.CalculadoraPro = { evaluateExpression, sendCalculationToApi };
})();
