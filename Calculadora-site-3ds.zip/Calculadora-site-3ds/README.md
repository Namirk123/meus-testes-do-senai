# Calculadora Pro

Projeto: site de calculadora profissional, acessível e preparado para integração com API.

Como usar
- Abra `index.html` no navegador (ou rode um servidor estático).
- Use os botões ou o teclado (Enter = calcular, Backspace = apagar, Esc = limpar).

Estrutura do projeto

- index.html — HTML5 semântico, SEO (title, meta description, Open Graph), acessibilidade (skip link, ARIA).
- css/style.css — estilos mobile-first, variáveis em `:root`, metodologia BEM.
- js/script.js — lógica da calculadora, teclado, histórico, placeholder para integração com API (`/api/calculations`).
- assets/ — imagens e favicon (logo.svg, favicon.svg).

Boas práticas aplicadas
- Acessibilidade: botões nativos, `aria-live` para o display e histórico, foco visível, skip-link.
- Performance: layout simples, SVG para logo/favicon, carregamento do script com `defer`.
- SEO/Open Graph: `title`, `meta description`, `og:*` e `canonical`.
- Preparado para API: `js/script.js` contém `sendCalculationToApi` como exemplo de integração.

Próximos passos sugeridos
- Adicionar testes unitários para `evaluateExpression`.
- Implementar backend `/api/calculations` para persistir histórico.
- Otimizar assets e adicionar CI/CD.
