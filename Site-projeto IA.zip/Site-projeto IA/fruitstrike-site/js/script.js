/* FruitStrike - core game logic (local, single-player)
   - Mobile-first controls (touch/mouse/keyboard)
   - Two modes: pattern (find odd fruit) and falling (collect / avoid)
   - Score, combo, record saved in localStorage
   - API hooks: saveRecord(record) placeholder for future integration
*/

const STORAGE_KEY = 'fruitstrike.record.v1';
let state = {
  mode: 'pattern', // pattern | falling
  running: false,
  score: 0,
  combo: 0,
  record: 0,
  level: 1
};
// timer and power-up state
state.timeLeft = 0; // ms
state.timeLimit = 10000; // base time for pattern mode (ms)
state.slowUntil = 0; // timestamp when slow power-up expires
// power-up collectable count
state.powerCount = 0;
// pattern mode progression
state.patternCorrectTotal = 0; // cumulative correct answers in pattern mode
state.patternFruitPoolCount = 3; // start with 3 fruit types, expand up to FRUITS.length
state.patternMaxRows = 6;
// gameplay settings
state.speedMultiplier = 1;
state.mouseSensitivity = 0.2;

// Canvas and rendering
const canvas = document.getElementById('game-canvas');
const ctx = canvas && canvas.getContext ? canvas.getContext('2d') : null;
let rafId = null;

// Simple asset set (emoji fallback) - prepared for images in assets/
const FRUITS = ['🍎','🍊','🍇','🍋','🍓','🍉'];
const BAD_ITEMS = ['💣','👾'];

// UI elements
const ui = {
  mode: document.getElementById('mode'),
  start: document.getElementById('start'),
  pause: document.getElementById('pause'),
  reset: document.getElementById('reset'),
  score: document.getElementById('score'),
  combo: document.getElementById('combo'),
  record: document.getElementById('record')
};
// extra UI elements (time and power-up displays)
ui.time = document.getElementById('time');
ui.power = document.getElementById('power');
ui.patternTimer = document.getElementById('pattern-timer');
ui.fullscreen = document.getElementById('fullscreen');
ui.speed = document.getElementById('speed');
ui.sensitivity = document.getElementById('sensitivity');
ui.speedLabel = document.getElementById('speed-label');
ui.sensitivityLabel = document.getElementById('sensitivity-label');
ui.playNow = document.getElementById('play-now');
const overlay = document.getElementById('overlay');
const overlayTitle = document.getElementById('overlay-title');
const overlayMessage = document.getElementById('overlay-message');
const overlayRestart = document.getElementById('overlay-restart');

function setOverlayAction(text, handler){
  if(!overlayRestart) return;
  // remove previous listeners by cloning
  const newBtn = overlayRestart.cloneNode(true);
  overlayRestart.parentNode.replaceChild(newBtn, overlayRestart);
  // reassign reference
  window._overlayRestart = newBtn;
  newBtn.textContent = text;
  newBtn.addEventListener('click', handler);
}

// helper to get current overlayRestart reference
function getOverlayButton(){ return document.getElementById('overlay-restart') || window._overlayRestart; }

// Game objects for falling mode
let fallingObjects = [];
let playerX = 0; // horizontal position for catching (0..canvas.width)

// Pattern mode grid
let grid = {cols:4,rows:3,cells:[]};

// Initialize
function init(){
  loadRecord();
  bindUI();
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  // default focus for accessibility
  ui.mode && ui.mode.focus();
}

function bindUI(){
  ui.mode && ui.mode.addEventListener('change', e=>{ state.mode = e.target.value; updateModeUI(); });
  ui.start && ui.start.addEventListener('click', startGame);
  ui.pause && ui.pause.addEventListener('click', togglePause);
  ui.reset && ui.reset.addEventListener('click', resetGame);
  ui.fullscreen && ui.fullscreen.addEventListener('click', toggleFullscreen);
  if(ui.speed) ui.speed.addEventListener('input', (e)=>{ state.speedMultiplier = Number(e.target.value); if(ui.speedLabel) ui.speedLabel.textContent = state.speedMultiplier.toFixed(1); });
  if(ui.sensitivity) ui.sensitivity.addEventListener('input', (e)=>{ state.mouseSensitivity = Number(e.target.value); if(ui.sensitivityLabel) ui.sensitivityLabel.textContent = state.mouseSensitivity.toFixed(2); });
  if(ui.playNow) ui.playNow.addEventListener('click', (e)=>{
    try{ e.preventDefault(); }
    catch(e){}
    // scroll to play section
    const playSection = document.getElementById('play');
    if(playSection) playSection.scrollIntoView({behavior:'smooth', block:'center'});
    // hide overlay if visible and start the game
    try{ hideOverlay(); }catch(e){}
    if(!state.running) startGame();
  });
  // keyboard controls for player
  window.addEventListener('keydown', (e)=>{
    if(state.mode === 'falling'){
      if(e.key === 'ArrowLeft') playerX -= 30;
      if(e.key === 'ArrowRight') playerX += 30;
    }
    if(e.key === ' ') togglePause();
  });
  // touch/mouse support to move player in falling mode
  // track pointer globally so movement works even outside the canvas
  window.addEventListener('pointermove', (e)=>{
    if(!canvas) return;
    const rect = canvas.getBoundingClientRect();
    // compute target relative to canvas
    let targetX = e.clientX - rect.left;
    // clamp to canvas bounds
    targetX = Math.max(0, Math.min(rect.width, targetX));
    // smoothing using sensitivity, but snap when very close to avoid "travar" with low sensitivity
    const smoothing = (typeof state.mouseSensitivity === 'number') ? state.mouseSensitivity : 0.2;
    const delta = targetX - playerX;
    const snapThreshold = 1; // pixels
    if(Math.abs(delta) <= snapThreshold) {
      playerX = targetX;
    } else {
      playerX += delta * smoothing;
    }
  });
}

function toggleFullscreen(){
  try{
    const elem = document.getElementById('game-area') || document.documentElement;
    if(!document.fullscreenElement){
      if(elem.requestFullscreen) elem.requestFullscreen();
      else if(elem.webkitRequestFullscreen) elem.webkitRequestFullscreen();
      if(ui.fullscreen) ui.fullscreen.textContent = 'Sair tela cheia';
    } else {
      if(document.exitFullscreen) document.exitFullscreen();
      else if(document.webkitExitFullscreen) document.webkitExitFullscreen();
      if(ui.fullscreen) ui.fullscreen.textContent = 'Tela cheia';
    }
  }catch(e){console.warn('Fullscreen not available', e)}
}

// When fullscreen changes, update UI and resize the canvas to fit the new container
document.addEventListener('fullscreenchange', ()=>{
  try{
    if(ui.fullscreen) ui.fullscreen.textContent = document.fullscreenElement ? 'Sair tela cheia' : 'Tela cheia';
  }catch(e){}
  resizeCanvas();
});

function updateModeUI(){
  // add a body class to reflect current mode (useful for CSS hooks)
  try{ document.body.classList.toggle('mode-pattern', state.mode === 'pattern'); }catch(e){}
  // show/hide the large pattern timer only for pattern mode
  if(ui.patternTimer){
    if(state.mode === 'pattern') ui.patternTimer.classList.remove('hidden'); else ui.patternTimer.classList.add('hidden');
  }
  // small scoreboard time visibility: only meaningful in pattern mode
  if(ui.time){ ui.time.parentElement.style.display = state.mode === 'pattern' ? 'inline-block' : 'none'; }
  // change the option label for pattern mode to be more instructive
  if(ui.mode){
    const opt = ui.mode.querySelector('option[value="pattern"]');
    if(opt) opt.textContent = state.mode === 'pattern' ? 'Selecione o diferente' : 'Descobrir padrão';
  }
}

function resizeCanvas(){
  if(!canvas) return;
  // keep aspect ratio 16:9 and size to parent (works in fullscreen)
  const parent = canvas.parentElement || document.body;
  const parentW = parent.clientWidth || window.innerWidth;
  const padding = 20;
  const maxAllowed = 1200;
  const w = Math.max(200, Math.min(parentW - padding, maxAllowed));
  canvas.width = Math.floor(w);
  canvas.height = Math.round(canvas.width * 9/16);
}

function startGame(){
  if(state.running) return;
  state.running = true;
  state.score = 0; state.combo = 0; state.level = 1;
  // initialize timer only for pattern mode
  if(state.mode === 'pattern') state.timeLeft = state.timeLimit; else state.timeLeft = 0;
  updateUI();
  if(state.mode === 'pattern') initPatternMode();
  else initFallingMode();
  // reset timing to avoid large dt on resume
  lastTime = 0;
  rafId = requestAnimationFrame(loop);
  // enable pause button
  if(ui.pause){ ui.pause.disabled = false; ui.pause.textContent = 'Pausar'; }
}

function pauseGame(){
  state.running = false;
  if(rafId) cancelAnimationFrame(rafId);
  rafId = null;
  // reset lastTime so next start doesn't inherit previous timestamp
  lastTime = 0;
  if(ui.pause){ ui.pause.textContent = 'Retomar'; }
}

function resumeGame(){
  if(state.running) return;
  state.running = true;
  lastTime = 0;
  rafId = requestAnimationFrame(loop);
  if(ui.pause){ ui.pause.disabled = false; ui.pause.textContent = 'Pausar'; }
}

function togglePause(){
  if(state.running) pauseGame(); else resumeGame();
}

function resetGame(){
  pauseGame();
  state.score = 0; state.combo = 0; fallingObjects = []; grid.cells = [];
  // reset timer and power-ups
  state.timeLeft = 0; state.slowUntil = 0; state.powerCount = 0;
  hideOverlay();
  updateUI();
  clearCanvas();
}

/* ---------------- Pattern Mode ---------------- */
function initPatternMode(){
  // create grid of fruits and mark one odd fruit
  const total = grid.cols * grid.rows;
  const pool = FRUITS.slice(0, state.patternFruitPoolCount);
  const base = pool[Math.floor(Math.random()*pool.length)];
  const odd = pool.filter(f=>f!==base)[Math.floor(Math.random()*(Math.max(1,pool.length-1)))];
  grid.cells = [];
  const oddIndex = Math.floor(Math.random()*total);
  for(let i=0;i<total;i++){
    grid.cells.push({fruit: i===oddIndex?odd:base, index:i});
  }
  // click handler on canvas
  if(canvas){ canvas.removeEventListener('click', handlePatternClick); canvas.addEventListener('click', handlePatternClick); }
  drawPattern();
}

function handlePatternClick(e){
  if(!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  const cellW = canvas.width / grid.cols;
  const cellH = canvas.height / grid.rows;
  const col = Math.floor(x / cellW);
  const row = Math.floor(y / cellH);
  const idx = row * grid.cols + col;
  const cell = grid.cells[idx];
  if(!cell) return;
  // if clicked odd fruit -> +score & combo, else reset combo
  const baseFruit = grid.cells.find((c,i)=> i!==idx).fruit; // a simple way to get base
  if(cell.fruit !== baseFruit){
    // correct
    state.combo += 1;
    state.score += 10 * state.combo;
    state.level += 0.2;
    // track total corrects in pattern mode (for progression)
    state.patternCorrectTotal = (state.patternCorrectTotal || 0) + 1;
    // every 3 consecutive correct answers, add 3 seconds to the timer
    if(state.combo % 3 === 0){
      state.timeLeft = (state.timeLeft || 0) + 3000; // +3000 ms
    }
    // every 10 cumulative corrects in pattern mode, increase difficulty: more rows and fruit types
    if(state.patternCorrectTotal % 10 === 0){
      // increase rows up to patternMaxRows
      if(grid.rows < state.patternMaxRows) grid.rows = Math.min(state.patternMaxRows, grid.rows + 1);
      // increase fruit pool up to FRUITS.length
      if(state.patternFruitPoolCount < FRUITS.length) state.patternFruitPoolCount = Math.min(FRUITS.length, state.patternFruitPoolCount + 1);
    }
    // next round
    initPatternMode();
  } else {
    state.combo = 0;
    state.score = Math.max(0, state.score - 5);
    // penalty to time for wrong click
    state.timeLeft = Math.max(0, state.timeLeft - 1500);
  }
  updateUI();
}

function drawPattern(){
  if(!ctx) return;
  clearCanvas();
  const cellW = canvas.width / grid.cols;
  const cellH = canvas.height / grid.rows;
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = `${Math.round(Math.min(cellW,cellH)*0.5)}px serif`;
  grid.cells.forEach((c,i)=>{
    const col = i % grid.cols;
    const row = Math.floor(i / grid.cols);
    const cx = col*cellW + cellW/2;
    const cy = row*cellH + cellH/2;
    ctx.fillStyle = '#fff';
    ctx.fillRect(col*cellW+6, row*cellH+6, cellW-12, cellH-12);
    ctx.fillStyle = '#000';
    ctx.fillText(c.fruit, cx, cy);
  });
}

/* ---------------- Falling Mode ---------------- */
function initFallingMode(){
  fallingObjects = [];
  playerX = canvas.width/2;
  spawnInterval = Math.max(600 - state.level*20, 200);
  lastSpawn = 0;
}

let lastSpawn = 0; let spawnInterval = 600;

function updateFalling(dt){
  // dt in ms
  lastSpawn += dt;
  if(lastSpawn > spawnInterval){
    lastSpawn = 0;
    spawnObject();
  }
  // apply slow multiplier if power-up active
  const now = Date.now();
  const slowActive = now < (state.slowUntil || 0);
  const slowMultiplier = slowActive ? 0.5 : 1;
  // update objects
  for(let obj of fallingObjects){
    obj.y += obj.speed * dt/16 * slowMultiplier;
  }
  // collision with bottom or player
  const catchRadius = 30;
  for(let i=fallingObjects.length-1;i>=0;i--){
    const obj = fallingObjects[i];
    if(obj.y > canvas.height - 40){
      // check if player catches
      if(Math.abs(obj.x - playerX) < catchRadius){
        // caught
        if(obj.type === 'fruit'){
          state.combo += 1; state.score += 5 * state.combo; 
        } else if(obj.type === 'power'){
          // collect power-up: increment count and activate immediate slow
          state.powerCount = (state.powerCount || 0) + 1;
          const dur = 6000; state.slowUntil = Date.now() + dur;
        } else {
          // bad item
          state.combo = 0; state.score = Math.max(0, state.score - 20);
        }
      } else {
        // missed fruit => break combo
        if(obj.type === 'fruit') state.combo = 0;
      }
      fallingObjects.splice(i,1);
    }
  }
  // slightly increase difficulty
  state.level += 0.0005 * dt;
}

function spawnObject(){
  // sometimes spawn power-up
  const r = Math.random();
  const isBad = r < Math.min(0.08 + state.level*0.01, 0.25);
  const isPower = r >= 0.25 && r < 0.25 + 0.07; // ~7% chance
  const x = Math.random()*(canvas.width-40) + 20;
  const speed = (1 + Math.random()*2 + state.level*0.3) * (state.speedMultiplier || 1);
  if(isPower){
    fallingObjects.push({x, y:-20, speed, type:'power', char:'🐢'});
  } else {
    fallingObjects.push({x, y: -20, speed, type: isBad? 'bad' : 'fruit', char: isBad? BAD_ITEMS[Math.floor(Math.random()*BAD_ITEMS.length)] : FRUITS[Math.floor(Math.random()*FRUITS.length)]});
  }
}

function drawFalling(){
  if(!ctx) return;
  clearCanvas();
  // draw objects
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = '28px serif';
  fallingObjects.forEach(o => {
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(o.x, o.y, 20, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#000'; ctx.fillText(o.char, o.x, o.y);
  });
  // draw player (basket)
  ctx.fillStyle = '#000';
  // remove the yellow bar and draw only the basket emoji centered above bottom
  ctx.font = '28px serif';
  ctx.fillText('🧺', playerX, canvas.height-22);
}

/* ---------------- Loop & helpers ---------------- */
let lastTime = 0;
function loop(ts){
  if(!lastTime) lastTime = ts;
  const dt = ts - lastTime;
  lastTime = ts;
  if(!state.running){
    // ensure timing reset when stopped
    lastTime = 0;
    return;
  }
  // handle pattern mode timer
  if(state.mode === 'pattern'){
    // decrease time; faster as level increases
    const decay = 1 + Math.max(0, (state.level-1))*0.05;
    state.timeLeft -= dt * decay;
    if(state.timeLeft <= 0){
      state.timeLeft = 0; // clamp
      // defeat
      endWithDefeat('O tempo acabou!');
      return;
    }
  }
  if(state.mode === 'falling'){
    updateFalling(dt);
    drawFalling();
  }
  // pattern mode needs drawing each frame to show timer and grid
  if(state.mode === 'pattern') drawPattern();
  // pattern mode draws only when changed; but keep clearing to show UI
  updateUI();
  rafId = requestAnimationFrame(loop);
}

function clearCanvas(){ if(ctx){ ctx.clearRect(0,0,canvas.width,canvas.height); }}

function updateUI(){
  ui.score && (ui.score.textContent = String(Math.floor(state.score)));
  ui.combo && (ui.combo.textContent = String(state.combo));
  ui.record && (ui.record.textContent = String(state.record));
  if(ui.time){
    if(state.mode === 'pattern') ui.time.textContent = Math.ceil((state.timeLeft||0)/1000);
    else ui.time.textContent = '-';
  }
  // update large pattern timer (if present)
  if(ui.patternTimer){
    if(state.mode === 'pattern') ui.patternTimer.textContent = String(Math.ceil((state.timeLeft||0)/1000));
    else ui.patternTimer.textContent = '';
  }
  // power-up remaining
  const now = Date.now();
  if(ui.power){
    const count = state.powerCount || 0;
    if(state.slowUntil && now < state.slowUntil){
      ui.power.textContent = `${count} (slow ${Math.ceil((state.slowUntil - now)/1000)}s)`;
    } else {
      ui.power.textContent = count > 0 ? `${count}` : '-';
    }
  }
}

/* ---------------- Persistence & API hooks ---------------- */
function loadRecord(){
  try{ const v = localStorage.getItem(STORAGE_KEY); if(v) { state.record = Number(v); }}catch(e){console.warn(e)}
  updateUI();
}

function saveRecord(){
  try{ if(state.score > state.record){ state.record = Math.floor(state.score); localStorage.setItem(STORAGE_KEY, String(state.record)); }
    updateUI();
    // placeholder for remote API integration
    // saveRecordRemote(state.record).catch(()=>{});
  }catch(e){console.warn(e)}
}

function endWithDefeat(msg){
  pauseGame();
  // Save base record immediately
  saveRecord();
  // If pattern mode, change overlay button to 'Ver resultados' which will save and show details
  if(state.mode === 'pattern'){
    showOverlay('Derrota!', msg || 'O tempo acabou.');
    const btn = getOverlayButton();
    if(btn){
      btn.textContent = 'Ver resultados';
      // remove previous and attach new
      setOverlayAction('Ver resultados', ()=>{ showResults(); });
    }
  } else {
    showOverlay('Derrota!', msg || 'Você não encontrou a fruta a tempo.');
    setOverlayAction('Reiniciar', ()=>{ hideOverlay(); resetGame(); });
  }
}

function showResults(){
  // save final snapshot
  const result = {
    mode: state.mode,
    score: Math.floor(state.score || 0),
    combo: state.combo || 0,
    record: state.record || 0,
    totalCorrectPattern: state.patternCorrectTotal || 0,
    timestamp: Date.now()
  };
  try{ localStorage.setItem('fruitstrike.latestResult.v1', JSON.stringify(result)); }catch(e){console.warn(e)}
  // present results on overlay and change button to restart
  const msg = `Score: ${result.score}\nCombo: ${result.combo}\nRecorde: ${result.record}\nAcertos (padrão): ${result.totalCorrectPattern}`;
  showOverlay('Resultados', msg);
  setOverlayAction('Reiniciar', ()=>{ hideOverlay(); resetGame(); });
}

function showOverlay(title, message){
  if(overlayTitle) overlayTitle.textContent = title;
  if(overlayMessage) overlayMessage.textContent = message;
  if(overlay){ overlay.classList.remove('hidden'); overlay.setAttribute('aria-hidden','false'); }
}

function hideOverlay(){ if(overlay){ overlay.classList.add('hidden'); overlay.setAttribute('aria-hidden','true'); } }

// Example remote hook (not active) - replace URL to integrate
async function saveRecordRemote(record){
  // return fetch('/api/records',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({record})});
}

// On game end (simple condition): update record
window.addEventListener('beforeunload', ()=>{ saveRecord(); });

// When pattern mode is active, draw pattern to reflect state
function drawPatternIfNeeded(){ if(state.mode === 'pattern') drawPattern(); }

// small safety: if canvas missing, create fallback UI
if(!canvas || !ctx){ console.warn('Canvas not available — game disabled.'); }

// Start init after DOM ready
document.addEventListener('DOMContentLoaded', init);

// ensure UI matches current mode on load
document.addEventListener('DOMContentLoaded', ()=>{ updateModeUI(); updateUI(); });
