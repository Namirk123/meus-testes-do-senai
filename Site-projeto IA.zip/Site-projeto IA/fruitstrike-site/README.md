FruitStrike — Jogo local (single-player)

Arquivos:
- index.html — página principal (semântica, SEO, Open Graph)
- css/style.css — Mobile-First, variáveis em :root, BEM
- js/script.js — motor de jogo (dois modos), salvamento local e hooks para API
- assets/* — logo, imagens e og-image

Como abrir localmente (Windows):
1) Abra a pasta `fruitstrike-site` e dê duplo-clique em `index.html` (file://) — funciona em navegadores modernos.
2) Ou sirva com Python para evitar problemas: 
   cd "c:\Users\labsenai\Desktop\Atividades Julio-Nicolas\fruitstrike-site"
   python -m http.server 8080
   Abra http://localhost:8080

Testes rápidos:
- Selecione o modo e clique em Iniciar.
- Mode "Descobrir padrão": clique na fruta diferente dentro da grade.
- Mode "Frutas caindo": mova o mouse (ou setas) para pegar frutas.
- Pontuação e recorde são salvos em localStorage.

Integração futura:
- `saveRecordRemote(record)` em `js/script.js` é o placeholder para gravar pontuação em uma API.

Posso:
- implementar assets gráficos e animações mais ricas,
- adicionar telas de menu, som e controles avançados,
- conectar com backend para leaderboards (me passe a API).
