#define trigPin 9
#define echoPin 10
#define buzzer  8

// ── Configuração ──────────────────────────────────────────────────────────────
// Altere DIST_MINIMA para o mesmo valor configurado no campo "Alerta abaixo de"
// no site (padrão: 20 cm).
// O buzzer só emitirá som UMA VEZ ao entrar na zona de alerta.
// Ele voltará a soar apenas se o objeto se afastar e se aproximar novamente.
#define DIST_MINIMA 20   // cm — distância mínima para disparar o alerta

// ── Variáveis ─────────────────────────────────────────────────────────────────
long  duracao;
float distancia;
bool  alertaAtivo = false;   // evita bip contínuo enquanto objeto permanece próximo

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(buzzer,  OUTPUT);
  Serial.begin(9600);
}

void loop() {
  // Envia pulso ultrassônico
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // Lê o eco e calcula a distância em cm
  duracao   = pulseIn(echoPin, HIGH);
  distancia = duracao * 0.034 / 2;

  // Envia no formato esperado pelo site
  Serial.print("DIST:");
  Serial.println(distancia);

  // Buzzer: apita APENAS ao atingir a distância mínima (transição de fora para dentro)
  if (distancia <= DIST_MINIMA) {
    if (!alertaAtivo) {
      alertaAtivo = true;       // marca zona ativa — não repete o bip
      digitalWrite(buzzer, HIGH);
      delay(150);               // duração do bip: 150 ms
      digitalWrite(buzzer, LOW);
    }
  } else {
    alertaAtivo = false;        // objeto se afastou — libera o próximo bip
    digitalWrite(buzzer, LOW);
  }

  delay(200);
}
